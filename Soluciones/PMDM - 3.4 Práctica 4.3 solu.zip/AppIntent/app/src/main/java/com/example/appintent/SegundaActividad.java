package com.example.appintent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SegundaActividad extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_actividad);
    }
}